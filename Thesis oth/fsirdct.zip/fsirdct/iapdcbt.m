function [X, Vinv] = iapdcbt(Y)
   % Reference : Embedding Binary Image Watermark in DC Components of All
   % Phase Discrete Cosine Biorthogonal Transform
   [M, N, z] = size(Y);
   if(z ~= 1)
       disp('Implemented for single channel image\n');
   end
   if(M ~= N)
       disp('X should be an N by N matrix\n');
   end
   
   Y = double(Y);
   V = zeros(M,N);
   
   for m = 0:M-1
       for n = 0:N-1
           
           if (n == 0 )
               V(m+1,n+1) = (N-m)/(N^2);
           else
               V(m+1,n+1) = ((N-m)*cos((m*n*pi)/N) - ...
                   csc((n*pi)/N)*sin((m*n*pi)/N))/(N^2);
           end
           
       end
   end
   
   Vinv = inv(V);
   
   X = Vinv*Y*Vinv'; % without optimization
   
  
           
end