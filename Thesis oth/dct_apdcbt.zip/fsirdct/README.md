## Implementation of `Discrete Cosine Transform`

## Implementation of `Inverse Discrete Cosine Transform`

## Implementation of `APDCBT`

## Implementation of `Inverse APDCBT`